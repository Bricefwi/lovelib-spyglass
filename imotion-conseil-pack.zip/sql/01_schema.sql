
create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  domain text unique,
  name text,
  activity text,
  ca_estimate text,
  employees_estimate text,
  digital_maturity int,
  tech_stack jsonb,
  marketing_channels jsonb,
  ia_usage jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.pre_audits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  url text,
  email text,
  status text default 'pending',
  confidence numeric default 0.0,
  raw_sources jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.audit_results (
  id uuid primary key default gen_random_uuid(),
  pre_audit_id uuid references public.pre_audits(id) on delete cascade,
  summary text,
  scores jsonb,
  sections jsonb,
  scenarios jsonb,
  sources jsonb,
  html_report text,
  created_at timestamptz default now()
);

create table if not exists public.company_audits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  pre_audit_id uuid references public.pre_audits(id) on delete cascade,
  audit_result_id uuid references public.audit_results(id) on delete cascade,
  status text default 'pending',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  pre_audit_id uuid references public.pre_audits(id) on delete cascade,
  sender text,
  body text,
  created_at timestamptz default now()
);

create index if not exists idx_companies_domain on public.companies (domain);
create index if not exists idx_preaudits_company on public.pre_audits (company_id);
create index if not exists idx_companyaudits_company on public.company_audits (company_id);

alter table public.companies enable row level security;
alter table public.pre_audits enable row level security;
alter table public.audit_results enable row level security;
alter table public.company_audits enable row level security;
alter table public.messages enable row level security;

create policy if not exists companies_read_all on public.companies for select using (true);
create policy if not exists preaudits_read_all on public.pre_audits for select using (true);
create policy if not exists auditresults_read_all on public.audit_results for select using (true);
create policy if not exists companyaudits_read_all on public.company_audits for select using (true);
create policy if not exists messages_read_all on public.messages for select using (true);
