import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
const supabase = createClient(import.meta.env.VITE_SUPABASE_URL!, import.meta.env.VITE_SUPABASE_ANON_KEY!);
export default function AdminAudits(){ const [rows,setRows]=useState<any[]>([]); const [loading,setLoading]=useState(false);
useEffect(()=>{ supabase.from("pre_audits").select("*, companies(domain)").order("created_at",{ascending:false}).then(({data})=>setRows(data||[])); },[]);
const relancer=async(id:string)=>{ setLoading(true); const tpl=localStorage.getItem("report_template"); await fetch("/api/audit-generate",{method:"POST",headers:{'Content-Type':'application/json'},body:JSON.stringify({pre_audit_id:id,template_html:tpl})}); setLoading(false); location.reload(); };
return (<div className="p-6 max-w-6xl mx-auto"><h1 className="text-2xl font-bold mb-4">Admin • Audits</h1>
<table className="w-full text-sm"><thead><tr><th>Entreprise</th><th>URL</th><th>Statut</th><th>Confiance</th><th>Actions</th></tr></thead>
<tbody>{rows.map(r=>(<tr key={r.id} className="border-t"><td>{r.companies?.domain}</td><td><a href={r.url} target="_blank">{r.url}</a></td><td>{r.status}</td><td>{(r.confidence*100).toFixed(0)}%</td><td><button className="px-3 py-1 bg-red-600 text-white rounded" onClick={()=>relancer(r.id)} disabled={loading}>Relancer IA</button></td></tr>))}</tbody>
</table></div>); }