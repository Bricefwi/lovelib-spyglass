// /edge/audit-collect.ts
import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY!;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const PERPLEXITY_API_KEY = process.env.PERPLEXITY_API_KEY || "";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, { auth: { persistSession: false } });

type CollectInput = { url: string; email?: string };

export default async function handler(req: Request): Promise<Response> {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const body: CollectInput = await req.json();

  const domain = (new URL(body.url)).hostname.replace(/^www\./,"");

  const { data: companyRow, error: cErr } = await sb
    .from("companies")
    .upsert({ domain }, { onConflict: "domain" })
    .select()
    .single();
  if (cErr) return new Response(JSON.stringify({ error: cErr.message }), { status: 500 });

  const { data: pre, error: pErr } = await sb
    .from("pre_audits")
    .insert({ company_id: companyRow.id, url: body.url, email: body.email, status: "collecting" })
    .select()
    .single();
  if (pErr) return new Response(JSON.stringify({ error: pErr.message }), { status: 500 });

  let raw: any = [];
  try {
    const res = await fetch(body.url, { headers: { "User-Agent": "IMOTION-AuditBot/1.0" } });
    const html = await res.text();
    const title = (html.match(/<title>(.*?)<\/title>/i)?.[1] || "").trim();
    const desc = (html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i)?.[1] || "").trim();
    raw.push({ source: body.url, title, description: desc });
  } catch {}

  await sb.from("pre_audits").update({ raw_sources: raw }).eq("id", pre.id);

  return new Response(JSON.stringify({ ok: true, pre_audit_id: pre.id, company_id: companyRow.id }), { status: 200 });
}
