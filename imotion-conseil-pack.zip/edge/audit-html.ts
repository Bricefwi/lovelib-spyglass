// /edge/audit-html.ts
import { createClient } from "@supabase/supabase-js";
const sb = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!, { auth: { persistSession:false } });

export default async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const pre_audit_id = url.searchParams.get("pre_audit_id");
  if (!pre_audit_id) return new Response("Missing id", { status: 400 });
  const { data: row } = await sb.from("audit_results").select("*").eq("pre_audit_id", pre_audit_id).single();
  if (!row) return new Response("Not found", { status: 404 });
  return new Response(row.html_report, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
