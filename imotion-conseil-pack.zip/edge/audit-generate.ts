// /edge/audit-generate.ts
import { createClient } from "@supabase/supabase-js";
import Handlebars from "handlebars";

const SUPABASE_URL = process.env.SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY!;

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, { auth: { persistSession: false } });

export default async function handler(req: Request): Promise<Response> {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { pre_audit_id, template_html } = await req.json();

  const { data: pre, error } = await sb.from("pre_audits").select("*").eq("id", pre_audit_id).single();
  if (error || !pre) return new Response("Pre-audit not found", { status: 404 });

  const scores = { maturite: 45, marketing: 40, sales: 30, data: 35, ia: 20, tech: 50 };
  const sections = {
    marketing: "Visibilité perfectible (SEO local, contenus cas client). Mettre en place un calendrier éditorial et capter les demandes avec formulaires + tracking.",
    tech: "Stack WordPress repérée. Renforcer performances (Core Web Vitals), sécurité et instrumentation (analytics, CRM, events)."
  };
  const scenarios = [
    { type: "Ambitieux", benefices: "Accélération forte de la demande inbound.", risques: "Budget et capacité de production.", effort: { jours: 120, budget_eur: 25000 } },
    { type: "Raisonnable", benefices: "Gains réguliers, pilotage serein.", risques: "Impact plus lent.", effort: { jours: 60, budget_eur: 12000 } },
    { type: "Opportuniste", benefices: "Validation rapide de canaux.", risques: "Résultats moins durables.", effort: { jours: 30, budget_eur: 5000 } },
    { type: "Mix", benefices: "Équilibre horizon court/moyen.", risques: "Coordination des chantiers.", effort: { jours: 90, budget_eur: 18000 } }
  ];
  const sources = (pre.raw_sources || []).map((s: any) => ({ url: s.source || s.url, label: s.title || s.url, reliability: 0.8 }));

  const htmlTpl = Handlebars.compile(template_html);
  const html = htmlTpl({
    url: pre.url,
    summary: "Pré‑audit généré automatiquement sur la base d’indices publics et d’une consolidation initiale. Un audit complet viendra affiner ces conclusions.",
    scores,
    sections,
    kpis: [
      { label: "Trafic organique/mois (est.)", value: "N/D" },
      { label: "Conversion formulaire", value: "N/D" },
      { label: "Coût par lead (est.)", value: "N/D" }
    ],
    scenarios,
    sources,
    download_url: "#"
  });

  const { data: result } = await sb.from("audit_results").insert({
    pre_audit_id,
    summary: "Conclusions préliminaires",
    scores, sections, scenarios, sources,
    html_report: html
  }).select().single();

  await sb.from("pre_audits").update({ status: "generated", confidence: 0.6 }).eq("id", pre_audit_id);

  return new Response(JSON.stringify({ ok: true, audit_result_id: result.id }), { status: 200 });
}
