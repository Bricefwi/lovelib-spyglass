// /edge/audit-send.ts
import { createClient } from "@supabase/supabase-js";
const SUPABASE_URL = process.env.SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY!;
const RESEND_API_KEY = process.env.RESEND_API_KEY!;
const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, { auth: { persistSession:false } });

export default async function handler(req: Request): Promise<Response> {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const { pre_audit_id } = await req.json();

  const { data: pre } = await sb.from("pre_audits").select("*").eq("id", pre_audit_id).single();
  const { data: resu } = await sb.from("audit_results").select("*").eq("pre_audit_id", pre_audit_id).single();
  if (!pre || !resu) return new Response("Not found", { status: 404 });
  if (!pre.email) return new Response("No email", { status: 400 });

  const emailHtml = `
  <div style="font-family:Inter,Arial,sans-serif;background:#f8f9fb;padding:24px">
    <div style="max-width:720px;margin:auto;background:#fff;border-radius:16px;padding:24px">
      <h1 style="color:#d8232a">🔍 Résultat de votre Pré‑Audit Digital</h1>
      <p>Analyse de <strong>${pre.url}</strong></p>
      <div style="background:#fafafa;padding:12px;border-left:4px solid #d8232a;border-radius:8px;margin:14px 0">
        ${resu.summary}
      </div>
      <p><a href="${pre.url}" style="display:inline-block;padding:10px 16px;background:#d8232a;color:#fff;border-radius:10px;text-decoration:none">Voir votre rapport</a></p>
      <hr/>
      <p style="font-size:12px;color:#666">IMOTION • Rapport généré automatiquement</p>
    </div>
  </div>`;

  const r = await fetch("https://api.resend.com/emails",{
    method:"POST",
    headers:{ "Authorization": `Bearer ${RESEND_API_KEY}`, "Content-Type":"application/json" },
    body: JSON.stringify({ from: "IMOTION <onboarding@resend.dev>", to: [pre.email], subject: `[IMOTION] Pré‑Audit Digital – ${pre.url}`, html: emailHtml })
  });

  await sb.from("pre_audits").update({ status: "sent" }).eq("id", pre_audit_id);

  return new Response(JSON.stringify({ ok: r.ok }), { status: 200 });
}
