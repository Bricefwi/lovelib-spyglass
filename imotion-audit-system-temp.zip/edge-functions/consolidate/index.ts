import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_KEY);

async function logStep(pre_audit_id: string, step: string, status: 'queued'|'running'|'done'|'error', message?: string) {
  await supabase.from('audit_steps').insert({ pre_audit_id, step, status, message });
  const statusMap: Record<typeof status, string> = {
    queued: 'consolidating',
    running: 'consolidating',
    done: 'pre_report_ready',
    error: 'error'
  };
  await supabase.from('pre_audits').update({ last_step: step, status: statusMap[status] }).eq('id', pre_audit_id);
}

serve(async (req) => {
  try {
    if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
    const { searchParams } = new URL(req.url);
    const pre_audit_id = searchParams.get('pre_audit_id');
    if (!pre_audit_id) return new Response('Missing pre_audit_id', { status: 400 });

    await logStep(pre_audit_id, 'Consolidation IA', 'running');
    await new Promise(r=>setTimeout(r, 1500));

    const consolidated = {
      summary: "Synthèse consolidée : présence digitale moyenne, potentiel SEO, besoin d’orchestration commerciale.",
      scores: { marketing: 62, sales: 58, tech: 64, data: 55, ia: 42 },
      scenarios: [
        { type:"Ambitieux", benefices:"Accélération des leads", risques:"Budget & vélocité", effort:{jours:120, budget_eur:25000}},
        { type:"Raisonnable", benefices:"Progression continue", risques:"Impact plus lent", effort:{jours:60, budget_eur:12000}},
        { type:"Opportuniste", benefices:"Validation rapide canaux", risques:"Résultats volatils", effort:{jours:30, budget_eur:5000}},
        { type:"Mix", benefices:"Équilibre court/moyen terme", risques:"Coordination", effort:{jours:90, budget_eur:18000}}
      ],
      sources: [{ url:"https://example.com", label:"Site officiel", reliability:0.8 }]
    };

    const confidence = 78;

    await supabase.from('pre_audits').update({
      status: 'pre_report_ready',
      confidence,
      last_step: 'Pré-rapport généré',
      consolidated_json: consolidated
    }).eq('id', pre_audit_id);

    await logStep(pre_audit_id, 'Pré-rapport généré', 'done');

    return new Response(JSON.stringify({ status:'ok', pre_audit_id }), {
      headers: { 'content-type': 'application/json' }
    });
  } catch (e) {
    console.error(e);
    return new Response('Erreur consolidation', { status: 500 });
  }
});