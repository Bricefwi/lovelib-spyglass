import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_KEY);

serve(async (req) => {
  try {
    const { searchParams } = new URL(req.url);
    const pre_audit_id = searchParams.get("pre_audit_id");
    if (!pre_audit_id) return new Response("Missing pre_audit_id", { status: 400 });

    const { data: audit, error } = await supabase
      .from("pre_audits")
      .select("id, domain, status, confidence, consolidated_json")
      .eq("id", pre_audit_id)
      .single();
    if (error || !audit) return new Response("Audit not found", { status: 404 });

    const tplResp = await fetch(new URL("./rapport.html", import.meta.url));
    const template = await tplResp.text();

    const safe = (v: any) => (v == null ? "" : String(v));
    const json = audit.consolidated_json || {};
    const html = template
      .replaceAll("{{DOMAIN}}", safe(audit.domain))
      .replaceAll("{{STATUS}}", safe(audit.status))
      .replaceAll("{{CONFIDENCE}}", String(Math.round(audit.confidence || 0)))
      .replaceAll("{{SUMMARY}}", safe(json.summary || ""))
      .replaceAll("{{SCORES_JSON}}", JSON.stringify(json.scores || {}, null, 2))
      .replaceAll("{{SCENARIOS_JSON}}", JSON.stringify(json.scenarios || [], null, 2))
      .replaceAll("{{SOURCES_JSON}}", JSON.stringify(json.sources || [], null, 2));

    return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
  } catch (e) {
    console.error(e);
    return new Response("Internal error", { status: 500 });
  }
});