import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SERVICE_KEY);

async function logStep(pre_audit_id: string, step: string, status: 'queued'|'running'|'done'|'error', message?: string) {
  await supabase.from('audit_steps').insert({ pre_audit_id, step, status, message });
  const statusMap: Record<typeof status, string> = {
    queued: 'ai_running',
    running: 'ai_running',
    done: 'ai_running',
    error: 'error'
  };
  await supabase.from('pre_audits').update({ last_step: step, status: statusMap[status] }).eq('id', pre_audit_id);
}

serve(async (req) => {
  try {
    if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
    const body = await req.json().catch(() => ({}));
    const url = body.url as string | undefined;
    const pre_audit_id = body.pre_audit_id as string | undefined;

    if (!url && !pre_audit_id) return new Response('Provide url or pre_audit_id', { status: 400 });

    let preId = pre_audit_id;

    if (!preId && url) {
      const domain = new URL(url).hostname.replace(/^www\./,'');
      const { data: company, error: cErr } = await supabase
        .from('companies').upsert({ domain }, { onConflict: 'domain' }).select().single();
      if (cErr) return new Response(cErr.message, { status: 500 });

      const { data: pre, error: pErr } = await supabase
        .from('pre_audits')
        .insert({ company_id: company.id, domain, url, status: 'collecting', last_step: 'URL reçue' })
        .select().single();
      if (pErr) return new Response(pErr.message, { status: 500 });
      preId = pre.id;
    }

    await logStep(preId!, 'Collecte web (Perplexity)', 'running');
    await new Promise(r=>setTimeout(r, 800));
    await logStep(preId!, 'Collecte web (Perplexity)', 'done');

    await logStep(preId!, 'Analyse GPT', 'running');
    await new Promise(r=>setTimeout(r, 800));
    await logStep(preId!, 'Analyse GPT', 'done');

    await logStep(preId!, 'Validation Gemini', 'running');
    await new Promise(r=>setTimeout(r, 800));
    await logStep(preId!, 'Validation Gemini', 'done');

    await supabase.from('pre_audits').update({
      status: 'consolidating',
      confidence: 60,
      last_step: 'Consolidation IA'
    }).eq('id', preId!);

    return new Response(JSON.stringify({ status: 'ok', pre_audit_id: preId }), {
      headers: { 'content-type': 'application/json' }
    });
  } catch (e) {
    console.error(e);
    return new Response('Internal error', { status: 500 });
  }
});