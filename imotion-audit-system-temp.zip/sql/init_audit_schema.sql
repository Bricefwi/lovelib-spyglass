create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  domain text unique,
  name text,
  activity text,
  ca_estimate text,
  employees_estimate text,
  digital_maturity int,
  tech_stack jsonb,
  marketing_channels jsonb,
  ia_usage jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

do $$ begin
  create type audit_status as enum (
    'new','collecting','ai_running','consolidating','pre_report_ready','sent','needs_review','error'
  );
exception when duplicate_object then null; end $$;

create table if not exists public.pre_audits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  domain text,
  url text,
  email text,
  status audit_status default 'new',
  confidence numeric default 0.0,
  last_step text,
  report_html_url text,
  report_pdf_url text,
  consolidated_json jsonb,
  raw_sources jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.audit_steps (
  id uuid primary key default gen_random_uuid(),
  pre_audit_id uuid not null references public.pre_audits(id) on delete cascade,
  step text not null,
  status text not null check (status in ('queued','running','done','error')),
  started_at timestamptz default now(),
  ended_at timestamptz,
  message text
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  pre_audit_id uuid references public.pre_audits(id) on delete cascade,
  sender text,
  body text,
  created_at timestamptz default now()
);

create index if not exists idx_companies_domain on public.companies (domain);
create index if not exists idx_preaudits_company on public.pre_audits (company_id);
create index if not exists idx_audit_steps_pre on public.audit_steps (pre_audit_id);

alter table public.companies enable row level security;
alter table public.pre_audits enable row level security;
alter table public.audit_steps enable row level security;
alter table public.messages enable row level security;

do $$ begin
  create policy companies_read_all on public.companies for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy preaudits_read_all on public.pre_audits for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy audit_steps_read_all on public.audit_steps for select using (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy messages_read_all on public.messages for select using (true);
exception when duplicate_object then null; end $$;

create or replace view public.v_admin_audits as
select
  pa.id,
  coalesce(pa.domain, c.domain) as domain,
  pa.created_at,
  pa.status,
  pa.confidence,
  pa.last_step,
  pa.report_html_url,
  count(s.*) filter (where s.status='done') as steps_done
from pre_audits pa
left join companies c on c.id = pa.company_id
left join audit_steps s on s.pre_audit_id = pa.id
group by pa.id, c.domain;

insert into public.companies (domain, name, activity, digital_maturity)
values ('demo-company.test','Demo Company','Services B2B',55)
on conflict (domain) do nothing;

insert into public.pre_audits (company_id, domain, url, status, confidence, last_step, consolidated_json, raw_sources)
select c.id, c.domain, 'https://demo-company.test', 'pre_report_ready', 78, 'Pré-rapport généré',
       '{"summary":"Pré-audit de démonstration.","scores":{"marketing":60,"sales":58,"tech":62,"data":55,"ia":40},"scenarios":[{"type":"Ambitieux","benefices":"Gain rapide leads","risques":"Budget élevé"},{"type":"Raisonnable","benefices":"Progression stable","risques":"Impact plus lent"}],"sources":[{"url":"https://demo-company.test","label":"Site officiel","reliability":0.8}]}'::jsonb,
       '[{"source":"demo","profile":{"name":"Demo Company"}}]'::jsonb
from public.companies c
where c.domain='demo-company.test'
on conflict do nothing;

insert into public.audit_steps (pre_audit_id, step, status, message)
select pa.id, 'Collecte web (Perplexity)', 'done', 'Terminé' from public.pre_audits pa where pa.domain='demo-company.test'
union all
select pa.id, 'Analyse GPT', 'done', 'Terminé' from public.pre_audits pa where pa.domain='demo-company.test'
union all
select pa.id, 'Validation Gemini', 'done', 'Terminé' from public.pre_audits pa where pa.domain='demo-company.test'
union all
select pa.id, 'Pré-rapport généré', 'done', 'OK' from public.pre_audits pa where pa.domain='demo-company.test';