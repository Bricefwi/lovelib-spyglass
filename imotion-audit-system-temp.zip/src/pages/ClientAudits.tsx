import React, { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

type Row = { id:string; domain:string; created_at:string; status:string; confidence:number|null };

const ORDER = ["new","collecting","ai_running","consolidating","pre_report_ready","sent"];
const val = (s:string)=> Math.max(0, Math.min(100, Math.round(((ORDER.indexOf(s)+1)/ORDER.length)*100)) );

export default function ClientAudits(){
  const [rows,setRows] = useState<Row[]>([]);
  const [loading,setLoading] = useState(true);

  useEffect(()=>{
    let cancel=false;
    (async()=>{
      setLoading(true);
      const { data, error } = await supabase.from("pre_audits").select("id,domain,created_at,status,confidence").order("created_at",{ascending:false});
      if (!cancel){
        if (error) console.error(error);
        setRows((data??[]) as Row[]);
        setLoading(false);
      }
    })();
    return ()=>{cancel=true};
  },[]);

  const openReport = (id:string)=> window.open(`/api/audit-html?pre_audit_id=${id}`,"_blank");

  return (
    <div className="container" style={{maxWidth:900,margin:"0 auto",padding:"24px"}}>
      <h1>Mes audits</h1>
      {loading? <div>Chargement…</div> : rows.map(r=>(
        <div key={r.id} style={{background:"#fff",borderRadius:14,padding:16,boxShadow:"0 1px 3px rgba(0,0,0,.08)",marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div>
              <div style={{fontWeight:700}}>{r.domain}</div>
              <div style={{fontSize:12,opacity:.7}}>Créé le {new Date(r.created_at).toLocaleString()}</div>
            </div>
            <button className="btn" onClick={()=>openReport(r.id)} disabled={["new","collecting","ai_running","consolidating"].includes(r.status)}>
              Voir le rapport
            </button>
          </div>
          <div style={{marginTop:12}}>
            <div style={{fontSize:12,opacity:.7,marginBottom:6}}>Progression</div>
            <div style={{height:10,background:"#eee",borderRadius:999}}>
              <div style={{height:"100%",width:`${val(r.status)}%`,background:"#e11d48",borderRadius:999,transition:"width .3s"}}/>
            </div>
            <div style={{fontSize:12,opacity:.7,marginTop:6}}>Statut : {r.status} • Confiance {Math.round(r.confidence??0)}%</div>
          </div>
        </div>
      ))}
    </div>
  );
}