import React, { useEffect, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

type Row = {
  id: string;
  domain: string;
  created_at: string;
  status: "new"|"collecting"|"ai_running"|"consolidating"|"pre_report_ready"|"sent"|"needs_review"|"error";
  confidence: number | null;
  last_step: string | null;
  report_html_url: string | null;
  steps_done: number;
};

type Step = {
  id: string;
  step: string;
  status: "queued"|"running"|"done"|"error";
  started_at: string;
  ended_at: string | null;
  message: string | null;
};

const STATUS_LABEL: Record<Row["status"], {label:string,color:string}> = {
  new:{label:"Nouveau",color:"#9aa0a6"},
  collecting:{label:"Collecte web",color:"#6d83f2"},
  ai_running:{label:"Analyse IA",color:"#fbbc05"},
  consolidating:{label:"Consolidation",color:"#fb8c00"},
  pre_report_ready:{label:"Pré-rapport prêt",color:"#7e57c2"},
  sent:{label:"Envoyé",color:"#1e88e5"},
  needs_review:{label:"À réviser",color:"#6d4c41"},
  error:{label:"Erreur",color:"#e53935"},
};

function Badge({status}:{status:Row["status"]}){
  const s=STATUS_LABEL[status];
  return <span style={{background:s.color,color:"#fff",padding:"4px 8px",borderRadius:12,fontSize:12}}>{s.label}</span>
}

export default function AdminAudits(){
  const [rows,setRows] = useState<Row[]>([]);
  const [loading,setLoading] = useState(true);
  const [active,setActive] = useState<string|null>(null);
  const [steps,setSteps] = useState<Record<string,Step[]>>({});
  const [refresh,setRefresh] = useState(0);

  useEffect(()=>{
    let cancelled=false;
    (async()=>{
      setLoading(true);
      const { data, error } = await supabase.from("v_admin_audits").select("*").order("created_at",{ascending:false});
      if (!cancelled){
        if (error) console.error(error);
        setRows((data??[]) as Row[]);
        setLoading(false);
      }
    })();
    return ()=>{cancelled=true};
  },[refresh]);

  const fetchSteps = async (id:string)=>{
    if (steps[id]) return;
    const { data, error } = await supabase.from("audit_steps").select("*").eq("pre_audit_id",id).order("started_at",{ascending:true});
    if (!error) setSteps(prev=>({...prev,[id]: data as Step[]}));
  };

  const toggle = async (id:string)=>{
    if (active===id){ setActive(null); return; }
    await fetchSteps(id);
    setActive(id);
  };

  const call = async (url:string, opts?:RequestInit)=>{
    const res = await fetch(url, { method:"POST", ...(opts||{}) });
    if (!res.ok) throw new Error(await res.text());
  };

  const relancer = async (row:Row)=>{
    try{ await call(`/api/preaudit`, { body: JSON.stringify({ pre_audit_id: row.id }), headers:{'Content-Type':'application/json'} }); setRefresh(v=>v+1); }
    catch(e:any){ alert("Erreur relance IA: "+e.message); }
  };

  const consolider = async (row:Row)=>{
    try{ await call(`/api/consolidate?pre_audit_id=${row.id}`); setRefresh(v=>v+1); }
    catch(e:any){ alert("Erreur consolidation: "+e.message); }
  };

  const openReport = (row:Row)=> window.open(`/api/audit-html?pre_audit_id=${row.id}`,"_blank");

  const header = useMemo(()=>(
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",margin:"24px 0"}}>
      <h1 style={{margin:0}}>Pilotage des audits</h1>
      <div style={{opacity:.7,fontSize:14}}>{rows.length} audits • {rows.filter(r=>r.status==='pre_report_ready'||r.status==='sent').length} prêts</div>
    </div>
  ),[rows]);

  return (
    <div className="container" style={{maxWidth:1100,margin:"0 auto",padding:"24px"}}>
      {header}
      {loading? <div>Chargement…</div> : rows.map(r=>(
        <div key={r.id} style={{background:"#fff",borderRadius:14,padding:16,boxShadow:"0 1px 3px rgba(0,0,0,.08)",marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <div style={{fontWeight:700}}>{r.domain}</div>
              <Badge status={r.status}/>
              <div style={{fontSize:12,opacity:.7}}>Confiance {Math.round(r.confidence??0)}%</div>
              {r.last_step && <div style={{fontSize:12,opacity:.7}}>Dernière étape : {r.last_step}</div>}
            </div>
            <div style={{display:"flex",gap:8}}>
              <button className="btn" onClick={()=>openReport(r)}>Voir</button>
              <button className="btn secondary" onClick={()=>consolider(r)}>Forcer consolidation</button>
              <button className="btn danger" onClick={()=>relancer(r)}>Relancer IA</button>
              <button className="btn ghost" onClick={()=>toggle(r.id)}>{active===r.id?"Masquer étapes":"Voir étapes"}</button>
            </div>
          </div>
          {active===r.id && (
            <div style={{marginTop:14,borderTop:"1px dashed #e5e7eb",paddingTop:14}}>
              <Timeline steps={steps[r.id]||[]}/>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function Timeline({steps}:{steps:Step[]}){
  if (!steps.length) return <div style={{opacity:.6}}>Aucune étape enregistrée pour l’instant.</div>;
  return (
    <div style={{display:"grid",gap:10}}>
      {steps.map(s=>(
        <div key={s.id} style={{display:"grid",gridTemplateColumns:"160px 120px 1fr",gap:12,alignItems:"start"}}>
          <div style={{fontFamily:"monospace",fontSize:12,opacity:.7}}>{new Date(s.started_at).toLocaleString()}</div>
          <span style={{
            background: s.status==='done' ? '#10b981' : s.status==='running' ? '#fbbf24' : s.status==='error' ? '#ef4444' : '#9ca3af',
            color:"#fff",padding:"2px 8px",borderRadius:999,fontSize:12,width:"max-content"
          }}>{s.status}</span>
          <div>
            <div style={{fontWeight:600}}>{s.step}</div>
            {s.message && <div style={{opacity:.75,fontSize:13,marginTop:4}}>{s.message}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}