# Guide de Déploiement - Intégration Multi-Agent n8n

## 🎯 Ce qui a été modifié/ajouté

### 1. Base de Données (Supabase)

**Nouvelle migration SQL** : `supabase/migrations/20251029000001_multi_agent_tables.sql`

Cette migration crée :
- Table `audit_phases` : Track les phases et agents du workflow n8n
- Table `agent_executions` : Métriques de performance (tokens, coût, latence)
- Vue `audit_overview` : Vue d'ensemble des audits avec métriques agrégées
- Colonnes additionnelles dans `audit_results` : `audit_type`, `phases_summary`

### 2. Nouvelle Edge Function

**`supabase/functions/orchestrate-multi-agent/index.ts`**

Cette fonction :
- Appelle le webhook n8n avec le contexte client
- Track les phases et agents dans la BDD
- Sauvegarde les résultats et métriques
- Envoie l'email avec le rapport final

### 3. Frontend

**Nouveaux composants** :
- `src/components/AuditProgress.tsx` : Affiche la progression en temps réel
- `src/components/PreAuditForm.tsx` : Modifié pour supporter 2 types d'audit

**Fonctionnalités** :
- Choix entre "Audit Standard" (5 min) et "Audit Approfondi" (15-20 min)
- Affichage en temps réel de la progression des 4 phases
- Tracking de chaque agent avec son statut
- Barre de progression globale

---

## 📋 Prérequis

1. ✅ **Workflow n8n déployé et actif**
   - URL webhook : `https://n8n.srv990696.hstgr.cloud/webhook-test/dcd15142-bbf7-48bc-989f-3d78efde3eac`

2. ✅ **Clés API configurées dans n8n**
   - `ANTHROPIC_API_KEY` (Claude)
   - `OPENAI_API_KEY` (GPT-4)
   - `TAVILY_API_KEY` (optionnel - recherche web)
   - `SERPER_API_KEY` (optionnel - recherche Google)
   - `JINA_API_KEY` (optionnel - scraping)

3. ✅ **Supabase configuré**
   - Accès admin au projet Supabase
   - CLI Supabase installé (optionnel mais recommandé)

---

## 🚀 Étapes de Déploiement

### Étape 1 : Appliquer la Migration SQL

**Option A - Via Supabase Dashboard** :
1. Va sur https://supabase.com/dashboard
2. Sélectionne ton projet
3. Va dans "SQL Editor"
4. Copie-colle le contenu de `supabase/migrations/20251029000001_multi_agent_tables.sql`
5. Exécute

**Option B - Via CLI** :
```bash
cd lovelib-spyglass-main
supabase db push
```

**Vérification** :
```sql
-- Vérifie que les tables sont créées
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('audit_phases', 'agent_executions');
```

---

### Étape 2 : Déployer la Nouvelle Edge Function

**Via CLI Supabase** :
```bash
cd lovelib-spyglass-main
supabase functions deploy orchestrate-multi-agent
```

**Configuration des variables d'environnement** :
```bash
# Dans le dashboard Supabase : Settings → Edge Functions → Configuration
N8N_WEBHOOK_URL=https://n8n.srv990696.hstgr.cloud/webhook-test/dcd15142-bbf7-48bc-989f-3d78efde3eac
ANTHROPIC_API_KEY=ta_cle_ici
OPENAI_API_KEY=ta_cle_ici
TAVILY_API_KEY=ta_cle_ici (optionnel)
SERPER_API_KEY=ta_cle_ici (optionnel)
JINA_API_KEY=ta_cle_ici (optionnel)
```

**Vérification** :
```bash
# Teste la fonction
curl -X POST \
  https://ton-projet.supabase.co/functions/v1/orchestrate-multi-agent \
  -H "Authorization: Bearer TON_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"pre_audit_id": "un-uuid-valide"}'
```

---

### Étape 3 : Déployer le Frontend

**Copie les fichiers modifiés** :
```bash
# Depuis le ZIP fourni, copie :
# - src/components/AuditProgress.tsx
# - src/components/PreAuditForm.tsx
```

**Install des dépendances (si besoin)** :
```bash
npm install
```

**Build & Deploy** :
```bash
npm run build
# Puis déploie via Lovable ou ton provider (Vercel, Netlify, etc.)
```

---

## 🧪 Tests

### Test 1 : Audit Standard (5 min)
1. Va sur ton site
2. Entre une URL test (ex: https://example.com)
3. Clique "Gratuit • 5 min"
4. Vérifie que le rapport arrive par email

### Test 2 : Audit Approfondi (15-20 min)
1. Entre une URL test
2. Clique "Lancer l'analyse IA avancée"
3. **Vérifie que le composant AuditProgress s'affiche**
4. **Vérifie que les phases se mettent à jour** (refresh toutes les 3 sec)
5. Attends la fin (15-20 min)
6. Vérifie que le rapport final arrive par email

### Test 3 : Vérifier la BDD
```sql
-- Regarde les phases créées
SELECT * FROM audit_phases ORDER BY created_at DESC LIMIT 20;

-- Regarde les métriques
SELECT * FROM agent_executions ORDER BY created_at DESC LIMIT 10;

-- Vue d'ensemble
SELECT * FROM audit_overview ORDER BY audit_started DESC;
```

---

## 🐛 Troubleshooting

### Problème : "n8n webhook failed"
**Solution** :
1. Vérifie que l'URL webhook est correcte dans les variables d'environnement
2. Teste le webhook directement avec curl
3. Vérifie les logs n8n

### Problème : "Pre-audit not found"
**Solution** :
1. Vérifie que la fonction `preaudit` fonctionne bien
2. Regarde les logs Supabase Edge Functions
3. Vérifie que le `pre_audit_id` est bien retourné

### Problème : Le composant AuditProgress ne se met pas à jour
**Solution** :
1. Ouvre les DevTools → Network
2. Vérifie que les requêtes vers `audit_phases` sont bien envoyées toutes les 3 sec
3. Vérifie les permissions RLS sur la table `audit_phases`

### Problème : Coûts IA trop élevés
**Solution** :
1. Regarde la vue `audit_overview` pour voir les coûts réels
2. Ajuste les paramètres `max_tokens` dans le workflow n8n
3. Active le caching dans n8n

---

## 📊 Monitoring

### Métriques à suivre

**Dans Supabase** :
```sql
-- Nombre d'audits par type
SELECT audit_type, COUNT(*) 
FROM audit_results 
GROUP BY audit_type;

-- Coût moyen par audit approfondi
SELECT 
  AVG(total_cost_usd) as avg_cost,
  AVG(total_tokens_used) as avg_tokens
FROM audit_overview
WHERE phases_completed > 0;

-- Taux de succès des agents
SELECT 
  phase_number,
  agent_name,
  COUNT(*) as total,
  SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
  ROUND(100.0 * SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) / COUNT(*), 2) as success_rate
FROM audit_phases
GROUP BY phase_number, agent_name
ORDER BY phase_number, agent_name;
```

**Dans n8n** :
- Dashboard → Executions
- Regarde les erreurs
- Temps d'exécution moyen

---

## 💰 Estimation des Coûts

### Par audit approfondi (estimé)

Avec le workflow actuel (4 phases, ~12 agents) :

```
Phase 1 (4 agents × GPT-4) : 8000 tokens → ~0.16€
Phase 2 (4 agents × Claude 3.5) : 12000 tokens → ~0.24€
Phase 3 (4 agents × GPT-4) : 10000 tokens → ~0.20€
Phase 4 (2 agents × Claude Opus) : 6000 tokens → ~0.30€

TOTAL : ~0.90€ par audit approfondi
```

**Stratégie de pricing recommandée** :
- Audit Standard : Gratuit (lead magnet)
- Audit Approfondi : 199€ HT
  - Coût IA : 0.90€
  - Marge brute : 198.10€ (99.5%)

---

## 🔐 Sécurité

### RLS (Row Level Security)

Ajoute ces policies dans Supabase :

```sql
-- audit_phases : lecture publique pour l'utilisateur qui a lancé l'audit
CREATE POLICY "Users can view their own audit phases"
ON audit_phases FOR SELECT
USING (
  pre_audit_id IN (
    SELECT id FROM pre_audits WHERE email = auth.jwt() ->> 'email'
  )
);

-- agent_executions : lecture admin uniquement
CREATE POLICY "Only admins can view agent executions"
ON agent_executions FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role = 'admin'
  )
);
```

### Rate Limiting

Dans `orchestrate-multi-agent/index.ts`, ajoute :
```typescript
// Limite : 1 audit approfondi par jour par email
const { count } = await supabase
  .from('audit_results')
  .select('*', { count: 'exact', head: true })
  .eq('audit_type', 'deep')
  .gte('created_at', new Date(Date.now() - 24*60*60*1000).toISOString());

if (count && count >= 1) {
  return new Response(
    JSON.stringify({ error: "Limite d'1 audit approfondi/jour atteinte" }),
    { status: 429, headers: corsHeaders }
  );
}
```

---

## 🎓 Formation de l'Équipe

### Pour les développeurs
- Comment fonctionne n8n
- Architecture multi-agent
- Débogage des Edge Functions

### Pour le support
- Interpréter les rapports
- Troubleshooting utilisateur
- Monitoring des coûts

### Pour le business
- Positionnement commercial
- Pricing de l'audit approfondi
- Upsell vers missions complètes

---

## 📚 Ressources

- [Documentation n8n](https://docs.n8n.io/)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Anthropic API](https://docs.anthropic.com/)
- [OpenAI API](https://platform.openai.com/docs)

---

## ✅ Checklist de Mise en Production

- [ ] Migration SQL appliquée
- [ ] Edge Function déployée
- [ ] Variables d'environnement configurées
- [ ] Frontend déployé
- [ ] Test audit standard OK
- [ ] Test audit approfondi OK
- [ ] Monitoring configuré
- [ ] Rate limiting activé
- [ ] RLS policies configurées
- [ ] Documentation à jour
- [ ] Équipe formée
- [ ] Pricing défini
- [ ] Communication prête

---

## 🚀 Prêt à déployer !

Une fois cette checklist validée, ton application sera prête à offrir des audits multi-agent de classe mondiale ! 🎉

**Besoin d'aide ?** Contacte l'équipe technique ou consulte les logs Supabase.
