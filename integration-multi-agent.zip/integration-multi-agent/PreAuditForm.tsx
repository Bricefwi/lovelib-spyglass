import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AuditProgress } from "./AuditProgress";

type AuditType = 'standard' | 'deep';

export const PreAuditForm = () => {
  const [website, setWebsite] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState<"idle" | "collecting" | "generating" | "progress" | "done" | "error">("idle");
  const [currentPreAuditId, setCurrentPreAuditId] = useState<string | null>(null);
  const [selectedAuditType, setSelectedAuditType] = useState<AuditType>('standard');
  const { toast } = useToast();

  const handleSubmit = async (auditType: AuditType) => {
    if (!website) {
      toast({
        title: "URL requise",
        description: "Veuillez entrer l'URL de votre site web",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    setStep("collecting");
    setSelectedAuditType(auditType);
    
    try {
      // Étape 1: Collecte multi-sources
      toast({
        title: "🔍 Collecte des données...",
        description: "Analyse de votre site et recherche d'informations publiques",
      });

      const { data: preAuditData, error: preAuditError } = await supabase.functions.invoke('preaudit', {
        body: { url: website }
      });

      if (preAuditError) throw preAuditError;

      const preAuditId = preAuditData?.pre_audit_id;
      if (!preAuditId) {
        throw new Error("Pre-audit ID not returned");
      }

      setCurrentPreAuditId(preAuditId);

      if (auditType === 'standard') {
        // Audit standard : un seul appel IA rapide
        setStep("generating");
        toast({
          title: "🤖 Génération du rapport...",
          description: "L'IA analyse les données et rédige votre pré-audit personnalisé",
        });

        const { data: auditData, error: auditError } = await supabase.functions.invoke('audit-generate', {
          body: { pre_audit_id: preAuditId }
        });

        if (auditError) throw auditError;

        // Succès
        setStep("done");
        toast({
          title: "✅ Audit standard terminé !",
          description: `Votre rapport pour ${website} est prêt. Consultez votre email.`,
        });
        setWebsite("");
        setIsLoading(false);
        setTimeout(() => setStep("idle"), 3000);

      } else {
        // Audit approfondi : orchestration multi-agent avec n8n
        setStep("progress");
        toast({
          title: "🚀 Lancement de l'audit approfondi...",
          description: "Plusieurs agents IA vont analyser votre entreprise en profondeur (15-20 min)",
        });

        const { data: orchestrateData, error: orchestrateError } = await supabase.functions.invoke('orchestrate-multi-agent', {
          body: { pre_audit_id: preAuditId }
        });

        if (orchestrateError) throw orchestrateError;

        // On reste en mode "progress" pour afficher le composant AuditProgress
        // qui va poller la BDD pour afficher l'avancement en temps réel
      }
      
    } catch (error: any) {
      console.error('Error during audit:', error);
      setStep("error");
      toast({
        title: "Erreur",
        description: error.message || "Impossible de générer l'audit. Veuillez réessayer.",
        variant: "destructive",
      });
      setIsLoading(false);
      setTimeout(() => setStep("idle"), 3000);
    }
  };

  const handleProgressComplete = () => {
    setStep("done");
    setIsLoading(false);
    toast({
      title: "✅ Audit approfondi terminé !",
      description: `Votre rapport ultra-détaillé pour ${website} est prêt. Consultez votre email.`,
    });
    setWebsite("");
    setTimeout(() => {
      setStep("idle");
      setCurrentPreAuditId(null);
    }, 5000);
  };

  return (
    <section id="audit" className="py-24 px-6 bg-background">
      <div className="container mx-auto max-w-4xl">
        {step === "progress" && currentPreAuditId ? (
          // Afficher la progression de l'audit approfondi
          <div className="space-y-6">
            <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
              <CardHeader>
                <CardTitle className="text-3xl">Audit Approfondi Multi-Agent en cours</CardTitle>
                <CardDescription className="text-white/90">
                  Plusieurs agents IA spécialisés analysent votre entreprise en profondeur
                </CardDescription>
              </CardHeader>
            </Card>
            <AuditProgress preAuditId={currentPreAuditId} onComplete={handleProgressComplete} />
          </div>
        ) : (
          // Afficher le formulaire
          <Card className="bg-card border border-border shadow-lg">
            <CardHeader className="text-center pb-8">
              <CardTitle className="text-4xl md:text-5xl mb-4 text-foreground">Audit Digital</CardTitle>
              <CardDescription className="text-lg text-muted-foreground">
                Évaluez la maturité digitale de votre entreprise
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <Input
                    type="url"
                    placeholder="https://www.votre-entreprise.com"
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    className="h-14 text-lg"
                    disabled={isLoading}
                  />
                </div>

                {/* Deux options d'audit */}
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Audit Standard */}
                  <Card className="border-2 hover:border-primary transition-colors cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center space-x-2">
                        <Zap className="h-5 w-5 text-blue-500" />
                        <CardTitle className="text-xl">Audit Standard</CardTitle>
                      </div>
                      <CardDescription>
                        Analyse rapide en 5 minutes
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-muted-foreground mb-4">
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Analyse de base du site</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Scores de maturité</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Rapport synthétique</span>
                        </li>
                      </ul>
                      <Button 
                        onClick={() => handleSubmit('standard')} 
                        className="w-full"
                        disabled={isLoading}
                      >
                        {isLoading && selectedAuditType === 'standard' ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            {step === "collecting" && "Collecte..."}
                            {step === "generating" && "Génération..."}
                            {step === "done" && "Terminé !"}
                          </>
                        ) : (
                          <>Gratuit • 5 min</>
                        )}
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Audit Approfondi */}
                  <Card className="border-2 border-purple-500 bg-gradient-to-br from-purple-50 to-blue-50 hover:shadow-lg transition-all cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center space-x-2">
                        <Sparkles className="h-5 w-5 text-purple-600" />
                        <CardTitle className="text-xl">Audit Approfondi</CardTitle>
                      </div>
                      <CardDescription>
                        Analyse multi-agent IA • 15-20 min
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-muted-foreground mb-4">
                        <li className="flex items-start">
                          <span className="text-purple-600 mr-2">✓</span>
                          <span><strong>4 phases</strong> d'analyse</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-purple-600 mr-2">✓</span>
                          <span><strong>12+ agents IA</strong> spécialisés</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-purple-600 mr-2">✓</span>
                          <span>Rapport ultra-détaillé</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-purple-600 mr-2">✓</span>
                          <span>Roadmap 90j + 12 mois</span>
                        </li>
                      </ul>
                      <Button 
                        onClick={() => handleSubmit('deep')} 
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        disabled={isLoading}
                      >
                        {isLoading && selectedAuditType === 'deep' ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            {step === "collecting" && "Collecte..."}
                            {step === "progress" && "En cours..."}
                          </>
                        ) : (
                          <>Lancer l'analyse IA avancée</>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                <p className="text-sm text-muted-foreground text-center">
                  Résultats envoyés par email • Aucun engagement
                </p>
              </div>

              {/* Détails des bénéfices */}
              <div className="mt-10 pt-8 border-t border-border">
                <h4 className="font-semibold mb-6 text-lg text-foreground">
                  {selectedAuditType === 'deep' ? 'L\'audit approfondi inclut :' : 'Ce que vous obtiendrez :'}
                </h4>
                {selectedAuditType === 'deep' ? (
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <span className="text-purple-600 mr-3 font-bold">📊</span>
                      <span><strong>Phase 1 - Étude de Marché:</strong> Analyse concurrentielle, SEO, tendances</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-purple-600 mr-3 font-bold">💬</span>
                      <span><strong>Phase 2 - Audits Conversationnels:</strong> Marketing, Sales, Tech, UX</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-purple-600 mr-3 font-bold">🎯</span>
                      <span><strong>Phase 3 - Analyses Spécialisées:</strong> Growth, Content, Analytics, IA</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-purple-600 mr-3 font-bold">📑</span>
                      <span><strong>Phase 4 - Synthèse:</strong> Rapport final avec vérifications croisées</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-purple-600 mr-3 font-bold">✨</span>
                      <span>4 scénarios détaillés avec ROI, budgets et timelines précis</span>
                    </li>
                  </ul>
                ) : (
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">✓</span>
                      <span>Collecte automatique des données de votre site</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">✓</span>
                      <span>Analyse de votre stack technique et présence digitale</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">✓</span>
                      <span>Rapport préliminaire avec opportunités identifiées</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">✓</span>
                      <span>4 scénarios chiffrés (ambitieux, raisonné, opportuniste, mix)</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">✓</span>
                      <span>Estimation ROI et recommandations prioritaires</span>
                    </li>
                  </ul>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
};
