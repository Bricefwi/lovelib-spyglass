# Intégration Multi-Agent n8n - Package Complet

## 📦 Contenu du Package

Ce package contient tous les fichiers nécessaires pour intégrer le workflow n8n multi-agent dans ton application IMOTION Spyglass.

### Structure des Fichiers

```
integration-multi-agent/
├── README.md (ce fichier)
├── DEPLOYMENT_GUIDE.md (guide de déploiement complet)
├── analyse_complete_imotion.md (analyse détaillée de l'application)
├── 20251029000001_multi_agent_tables.sql (migration SQL)
├── orchestrate-multi-agent/ (nouvelle Edge Function)
│   └── index.ts
├── AuditProgress.tsx (composant React progression)
└── PreAuditForm.tsx (composant React formulaire modifié)
```

---

## 🎯 Quick Start

### 1. Copie les fichiers dans ton repo

```bash
# Migration SQL
cp 20251029000001_multi_agent_tables.sql ton-repo/supabase/migrations/

# Edge Function
cp -r orchestrate-multi-agent ton-repo/supabase/functions/

# Composants React
cp AuditProgress.tsx ton-repo/src/components/
cp PreAuditForm.tsx ton-repo/src/components/
```

### 2. Applique la migration SQL

**Via Supabase Dashboard** :
1. Va sur https://supabase.com/dashboard
2. SQL Editor
3. Copie-colle le contenu de `20251029000001_multi_agent_tables.sql`
4. Exécute

**Ou via CLI** :
```bash
cd ton-repo
supabase db push
```

### 3. Déploie l'Edge Function

```bash
cd ton-repo
supabase functions deploy orchestrate-multi-agent
```

**Configure les variables d'environnement** dans Supabase Dashboard :
- `N8N_WEBHOOK_URL=https://n8n.srv990696.hstgr.cloud/webhook-test/dcd15142-bbf7-48bc-989f-3d78efde3eac`
- `ANTHROPIC_API_KEY=ta_cle`
- `OPENAI_API_KEY=ta_cle`
- (optionnel) `TAVILY_API_KEY`, `SERPER_API_KEY`, `JINA_API_KEY`

### 4. Déploie le Frontend

```bash
cd ton-repo
npm install
npm run build
# Puis déploie via Lovable, Vercel, etc.
```

### 5. Teste !

1. Va sur ton site
2. Entre une URL test
3. Clique sur "Lancer l'analyse IA avancée"
4. Regarde la magie opérer ! ✨

---

## 📚 Documentation Complète

**Lis absolument** :
1. `DEPLOYMENT_GUIDE.md` - Guide de déploiement détaillé avec troubleshooting
2. `analyse_complete_imotion.md` - Analyse complète de l'archi + recommandations

---

## 🆘 Besoin d'Aide ?

### Problèmes Courants

**"n8n webhook failed"**
→ Vérifie que l'URL webhook est correcte dans les variables d'env

**"Pre-audit not found"**
→ Vérifie que la fonction `preaudit` fonctionne

**Le composant AuditProgress ne se met pas à jour**
→ Vérifie les permissions RLS sur `audit_phases`

### Logs

**Supabase Edge Functions** :
```bash
supabase functions logs orchestrate-multi-agent
```

**n8n** :
Dashboard → Executions → Regarde les erreurs

---

## 🎉 C'est Tout !

Ton application est maintenant équipée d'un système multi-agent de folie qui va cartonner ! 🚀

**Prochain objectif** : Facturer ces audits approfondis à 199€ et faire du cash ! 💰
