import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const N8N_WEBHOOK_URL = Deno.env.get("N8N_WEBHOOK_URL") || "https://n8n.srv990696.hstgr.cloud/webhook-test/dcd15142-bbf7-48bc-989f-3d78efde3eac";
const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY");
const TAVILY_API_KEY = Deno.env.get("TAVILY_API_KEY");
const SERPER_API_KEY = Deno.env.get("SERPER_API_KEY");
const JINA_API_KEY = Deno.env.get("JINA_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ClientContext {
  name: string;
  sector: string;
  region: string;
  size: string;
  products: string[];
  budget: number;
  currency: string;
  objectives: string[];
  regulatory?: string[];
  internal_skills?: string[];
  time_horizon?: string;
}

interface N8nResponse {
  execution_id: string;
  status: string;
  phases?: Array<{
    phase: number;
    name: string;
    agents: Array<{
      id: string;
      name: string;
      status: string;
      output?: any;
      confidence?: number;
      sources?: any[];
      metrics?: {
        tokens: number;
        cost: number;
        latency: number;
      };
    }>;
  }>;
  final_report?: {
    summary: string;
    markdown: string;
    scores: any;
    scenarios: any[];
    sources: any[];
    confidence: number;
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Use POST", { status: 405, headers: corsHeaders });
  }

  try {
    const { pre_audit_id } = await req.json();
    
    if (!pre_audit_id) {
      return new Response(
        JSON.stringify({ error: "pre_audit_id required" }), 
        { 
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

    console.log("🚀 Starting multi-agent orchestration for pre_audit_id:", pre_audit_id);

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // 1) Récupérer le pre_audit avec ses données consolidées
    const { data: preAudit, error: fetchError } = await supabase
      .from("pre_audits")
      .select("*")
      .eq("id", pre_audit_id)
      .single();

    if (fetchError || !preAudit) {
      console.error("❌ Pre-audit not found:", fetchError);
      return new Response(
        JSON.stringify({ error: "Pre-audit not found" }), 
        { 
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

    const consolidated = preAudit.consolidated || {};
    const targetUrl = preAudit.url || "";

    // 2) Construire le contexte client pour n8n
    const clientContext: ClientContext = {
      name: consolidated.company_name || targetUrl,
      sector: consolidated.industry || "Non défini",
      region: consolidated.region || "France/EU",
      size: consolidated.employee_count || "PME",
      products: consolidated.products || [],
      budget: 100000,
      currency: "EUR",
      objectives: [
        "Améliorer la présence digitale",
        "Optimiser la conversion",
        "Automatiser le marketing"
      ],
      regulatory: ["RGPD"],
      internal_skills: consolidated.tech_stack || [],
      time_horizon: "2025-2027"
    };

    // 3) Préparer les clés API pour n8n
    const apiKeys = {
      openai: OPENAI_API_KEY || "",
      anthropic: ANTHROPIC_API_KEY || "",
      tavily: TAVILY_API_KEY || "",
      serper: SERPER_API_KEY || "",
      jina: JINA_API_KEY || ""
    };

    console.log("📡 Calling n8n webhook:", N8N_WEBHOOK_URL);

    // 4) Appeler le webhook n8n
    const n8nPayload = {
      client: clientContext,
      keys: apiKeys,
      report_language: "fr-FR",
      enable_caching: true,
      max_retries: 3
    };

    console.log("📦 Payload:", JSON.stringify(n8nPayload, null, 2));

    const n8nResponse = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(n8nPayload)
    });

    if (!n8nResponse.ok) {
      const errorText = await n8nResponse.text();
      console.error("❌ n8n webhook error:", n8nResponse.status, errorText);
      throw new Error(`n8n workflow failed: ${n8nResponse.status} - ${errorText}`);
    }

    const n8nResult: N8nResponse = await n8nResponse.json();
    console.log("✅ n8n workflow completed:", n8nResult.execution_id);

    // 5) Sauvegarder les phases dans la BDD
    if (n8nResult.phases && n8nResult.phases.length > 0) {
      console.log("💾 Saving phases to database...");
      
      for (const phase of n8nResult.phases) {
        for (const agent of phase.agents) {
          // Créer l'entrée audit_phase
          const { data: phaseData, error: phaseError } = await supabase
            .from("audit_phases")
            .insert({
              pre_audit_id,
              phase_number: phase.phase,
              phase_name: phase.name,
              agent_id: agent.id,
              agent_name: agent.name,
              status: agent.status,
              output_data: agent.output || {},
              confidence: agent.confidence || 0,
              sources: agent.sources || [],
              completed_at: agent.status === 'completed' ? new Date().toISOString() : null
            })
            .select()
            .single();

          if (phaseError) {
            console.error("⚠️ Error saving phase:", phaseError);
            continue;
          }

          // Créer l'entrée agent_execution si on a des métriques
          if (agent.metrics && phaseData) {
            await supabase
              .from("agent_executions")
              .insert({
                audit_phase_id: phaseData.id,
                model_used: agent.metrics.model || "unknown",
                provider: agent.metrics.provider || "unknown",
                prompt_tokens: agent.metrics.prompt_tokens || 0,
                completion_tokens: agent.metrics.completion_tokens || 0,
                total_tokens: agent.metrics.tokens || 0,
                cost_usd: agent.metrics.cost || 0,
                latency_ms: agent.metrics.latency || 0,
                temperature: agent.metrics.temperature || 0.5,
                max_tokens: agent.metrics.max_tokens || 4000,
                success: agent.status === 'completed'
              });
          }
        }
      }
    }

    // 6) Sauvegarder le rapport final dans audit_results
    if (n8nResult.final_report) {
      console.log("📝 Saving final report...");
      
      const { data: savedReport, error: reportError } = await supabase
        .from("audit_results")
        .insert({
          pre_audit_id,
          audit_type: 'deep',
          summary: n8nResult.final_report.summary || "",
          report_md: n8nResult.final_report.markdown || "",
          scores: n8nResult.final_report.scores || {},
          scenarios: n8nResult.final_report.scenarios || [],
          sources: n8nResult.final_report.sources || [],
          confidence: n8nResult.final_report.confidence || 0,
          phases_summary: n8nResult.phases || []
        })
        .select()
        .single();

      if (reportError) {
        console.error("❌ Error saving report:", reportError);
        throw reportError;
      }

      console.log("✅ Report saved with id:", savedReport.id);

      // 7) Récupérer le report_id pour l'email
      const { data: reportData } = await supabase
        .from("audit_reports")
        .select("id")
        .eq("pre_audit_id", pre_audit_id)
        .single();

      // 8) Envoyer l'email avec les résultats
      try {
        console.log("📧 Sending email...");
        
        const { error: emailError } = await supabase.functions.invoke('send-audit-results', {
          body: {
            auditResultId: savedReport.id,
            website: targetUrl,
            reportMarkdown: n8nResult.final_report.markdown,
            scores: n8nResult.final_report.scores,
            reportId: reportData?.id
          }
        });

        if (emailError) {
          console.error("⚠️ Email sending failed:", emailError);
        } else {
          console.log("✅ Email sent successfully");
        }
      } catch (emailError) {
        console.error("⚠️ Email error:", emailError);
        // Continue même si l'email échoue
      }

      return new Response(
        JSON.stringify({ 
          audit_result_id: savedReport.id,
          execution_id: n8nResult.execution_id,
          status: "completed",
          phases_count: n8nResult.phases?.length || 0,
          confidence: n8nResult.final_report.confidence
        }), 
        { 
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    } else {
      // Si pas de rapport final, c'est que le workflow est encore en cours
      return new Response(
        JSON.stringify({ 
          execution_id: n8nResult.execution_id,
          status: n8nResult.status || "processing",
          message: "Workflow initiated successfully. Check status later."
        }), 
        { 
          status: 202,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        }
      );
    }

  } catch (error) {
    console.error("❌ Orchestration error:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : String(error),
        details: "Multi-agent orchestration failed"
      }), 
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});
