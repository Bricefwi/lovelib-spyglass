import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";

interface AgentStatus {
  id: string;
  name: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  confidence?: number;
  started_at?: string;
  completed_at?: string;
}

interface PhaseProgress {
  phase: number;
  name: string;
  agents: AgentStatus[];
  total_agents: number;
  completed_agents: number;
}

interface AuditProgressProps {
  preAuditId: string;
  onComplete?: () => void;
}

export const AuditProgress = ({ preAuditId, onComplete }: AuditProgressProps) => {
  const [phases, setPhases] = useState<PhaseProgress[]>([]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    const fetchProgress = async () => {
      const { data, error } = await supabase
        .from('audit_phases')
        .select('*')
        .eq('pre_audit_id', preAuditId)
        .order('phase_number', { ascending: true })
        .order('agent_name', { ascending: true });

      if (error) {
        console.error('Error fetching progress:', error);
        return;
      }

      if (!data || data.length === 0) {
        return;
      }

      // Grouper par phase
      const phaseMap = new Map<number, PhaseProgress>();
      
      data.forEach(item => {
        if (!phaseMap.has(item.phase_number)) {
          phaseMap.set(item.phase_number, {
            phase: item.phase_number,
            name: item.phase_name,
            agents: [],
            total_agents: 0,
            completed_agents: 0
          });
        }

        const phase = phaseMap.get(item.phase_number)!;
        phase.agents.push({
          id: item.agent_id,
          name: item.agent_name,
          status: item.status,
          confidence: item.confidence,
          started_at: item.started_at,
          completed_at: item.completed_at
        });
        phase.total_agents++;
        if (item.status === 'completed') {
          phase.completed_agents++;
        }
      });

      const phasesArray = Array.from(phaseMap.values());
      setPhases(phasesArray);

      // Calculer le progrès global
      const totalAgents = data.length;
      const completedAgents = data.filter(d => d.status === 'completed').length;
      const progress = totalAgents > 0 ? (completedAgents / totalAgents) * 100 : 0;
      setOverallProgress(progress);

      // Vérifier si tout est terminé
      const allComplete = data.every(d => d.status === 'completed' || d.status === 'failed');
      if (allComplete && !isComplete) {
        setIsComplete(true);
        if (onComplete) {
          onComplete();
        }
      }
    };

    // Fetch initial
    fetchProgress();

    // Poll toutes les 3 secondes si pas terminé
    const interval = setInterval(() => {
      if (!isComplete) {
        fetchProgress();
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [preAuditId, isComplete, onComplete]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-500">Terminé</Badge>;
      case 'failed':
        return <Badge variant="destructive">Échec</Badge>;
      case 'running':
        return <Badge variant="default" className="bg-blue-500">En cours</Badge>;
      default:
        return <Badge variant="secondary">En attente</Badge>;
    }
  };

  const getPhaseName = (phaseNum: number) => {
    const names: Record<number, string> = {
      1: "📊 Étude de Marché",
      2: "💬 Audits Conversationnels",
      3: "🎯 Analyses Spécialisées",
      4: "📑 Synthèse & Vérification"
    };
    return names[phaseNum] || `Phase ${phaseNum}`;
  };

  if (phases.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center space-x-2">
            <Loader2 className="h-6 w-6 animate-spin" />
            <p className="text-muted-foreground">Initialisation de l'audit multi-agent...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Progrès global */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Audit Multi-Agent en cours</span>
            <span className="text-2xl font-bold text-primary">
              {Math.round(overallProgress)}%
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={overallProgress} className="h-3" />
          <p className="text-sm text-muted-foreground mt-2">
            {isComplete 
              ? "✅ Analyse terminée ! Le rapport complet est en cours de génération..."
              : "L'IA analyse votre entreprise avec plusieurs agents spécialisés..."
            }
          </p>
        </CardContent>
      </Card>

      {/* Détail par phase */}
      {phases.map((phase) => (
        <Card key={phase.phase}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                {getPhaseName(phase.phase)}
              </CardTitle>
              <Badge variant="outline">
                {phase.completed_agents}/{phase.total_agents} agents
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {phase.agents.map((agent) => (
                <div 
                  key={agent.id} 
                  className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/5 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(agent.status)}
                    <div>
                      <p className="font-medium">{agent.name}</p>
                      {agent.confidence !== undefined && agent.status === 'completed' && (
                        <p className="text-xs text-muted-foreground">
                          Confiance: {Math.round(agent.confidence * 100)}%
                        </p>
                      )}
                    </div>
                  </div>
                  {getStatusBadge(agent.status)}
                </div>
              ))}
            </div>

            {/* Barre de progression de la phase */}
            <div className="mt-4">
              <Progress 
                value={(phase.completed_agents / phase.total_agents) * 100} 
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>
      ))}

      {isComplete && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2 text-green-700">
              <CheckCircle2 className="h-6 w-6" />
              <div>
                <p className="font-semibold">Analyse complète terminée !</p>
                <p className="text-sm">Votre rapport détaillé est prêt.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
