-- Migration pour supporter l'intégration multi-agent n8n
-- Créé le: 2025-10-29

-- Table pour tracker les phases d'audit multi-agent
CREATE TABLE IF NOT EXISTS audit_phases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pre_audit_id UUID REFERENCES pre_audits(id) ON DELETE CASCADE,
  phase_number INT NOT NULL,
  phase_name TEXT NOT NULL,
  agent_id TEXT NOT NULL,
  agent_name TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed')),
  input_data JSONB,
  output_data JSONB,
  confidence FLOAT,
  sources JSONB DEFAULT '[]'::jsonb,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  error_message TEXT,
  retry_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table pour tracker les exécutions des agents (métriques)
CREATE TABLE IF NOT EXISTS agent_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  audit_phase_id UUID REFERENCES audit_phases(id) ON DELETE CASCADE,
  model_used TEXT NOT NULL,
  provider TEXT NOT NULL,
  prompt_tokens INT,
  completion_tokens INT,
  total_tokens INT,
  cost_usd FLOAT,
  latency_ms INT,
  temperature FLOAT,
  max_tokens INT,
  success BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ajouter une colonne pour indiquer le type d'audit dans audit_results
ALTER TABLE audit_results 
ADD COLUMN IF NOT EXISTS audit_type TEXT DEFAULT 'standard' CHECK (audit_type IN ('standard', 'deep'));

ALTER TABLE audit_results 
ADD COLUMN IF NOT EXISTS phases_summary JSONB DEFAULT '[]'::jsonb;

-- Index pour optimiser les requêtes
CREATE INDEX IF NOT EXISTS idx_audit_phases_pre_audit ON audit_phases(pre_audit_id);
CREATE INDEX IF NOT EXISTS idx_audit_phases_status ON audit_phases(status);
CREATE INDEX IF NOT EXISTS idx_audit_phases_phase_number ON audit_phases(phase_number);
CREATE INDEX IF NOT EXISTS idx_agent_executions_phase ON agent_executions(audit_phase_id);

-- Trigger pour mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_audit_phases_updated_at BEFORE UPDATE ON audit_phases
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Vue pour avoir une vue d'ensemble de l'audit multi-agent
CREATE OR REPLACE VIEW audit_overview AS
SELECT 
  pa.id as pre_audit_id,
  pa.url,
  pa.email,
  pa.created_at as audit_started,
  COUNT(DISTINCT ap.phase_number) as phases_completed,
  COUNT(ap.id) as total_agents,
  SUM(CASE WHEN ap.status = 'completed' THEN 1 ELSE 0 END) as agents_completed,
  SUM(CASE WHEN ap.status = 'failed' THEN 1 ELSE 0 END) as agents_failed,
  SUM(CASE WHEN ap.status = 'running' THEN 1 ELSE 0 END) as agents_running,
  AVG(ap.confidence) as avg_confidence,
  SUM(ae.total_tokens) as total_tokens_used,
  SUM(ae.cost_usd) as total_cost_usd,
  AVG(ae.latency_ms) as avg_latency_ms
FROM pre_audits pa
LEFT JOIN audit_phases ap ON pa.id = ap.pre_audit_id
LEFT JOIN agent_executions ae ON ap.id = ae.audit_phase_id
GROUP BY pa.id, pa.url, pa.email, pa.created_at;

COMMENT ON TABLE audit_phases IS 'Tracker les phases et agents du workflow n8n multi-agent';
COMMENT ON TABLE agent_executions IS 'Métriques de performance pour chaque exécution d''agent';
COMMENT ON VIEW audit_overview IS 'Vue d''ensemble des audits multi-agent avec métriques agrégées';
