#!/usr/bin/env python3
"""
Script de Collecte Automatique d'Actualités IA
Collecte quotidienne depuis plusieurs sources et génération d'une synthèse
"""

import os
import json
import requests
from datetime import datetime, timedelta
from typing import List, Dict
from openai import OpenAI

# Configuration
PERPLEXITY_API_KEY = os.getenv("SONAR_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OUTPUT_DIR = "/home/ubuntu/ai-news-collector/data"
EMAIL_RECIPIENT = "patrice.simion@gmail.com"

# Sources d'actualités IA
AI_NEWS_SOURCES = [
    "TechCrunch AI",
    "VentureBeat AI",
    "The Verge AI",
    "MIT Technology Review",
    "OpenAI Blog",
    "Google AI Blog",
    "Anthropic News",
    "Hugging Face Blog",
    "Papers with Code",
    "AI Alignment Forum"
]

class AINewsCollector:
    """Collecteur d'actualités IA avec synthèse automatique"""
    
    def __init__(self):
        self.perplexity_api_key = PERPLEXITY_API_KEY
        self.openai_client = OpenAI(api_key=OPENAI_API_KEY)
        self.today = datetime.now().strftime("%Y-%m-%d")
        
    def collect_news_perplexity(self) -> str:
        """Collecte les actualités via Perplexity API"""
        
        print("🔍 Collecte des actualités IA via Perplexity...")
        
        query = f"""
        Quelles sont les actualités les plus importantes de l'industrie de l'IA 
        publiées dans les dernières 24 heures ?
        
        Inclure :
        - Nouvelles versions de modèles (GPT, Claude, Gemini, etc.)
        - Annonces de produits IA
        - Recherches académiques importantes
        - Financements et acquisitions dans l'IA
        - Régulations et politiques IA
        - Cas d'usage innovants
        
        Pour chaque actualité, fournir :
        - Titre
        - Source
        - Résumé (2-3 phrases)
        - Lien
        - Date
        """
        
        try:
            response = requests.post(
                "https://api.perplexity.ai/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.perplexity_api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "sonar-pro",
                    "messages": [
                        {
                            "role": "system",
                            "content": "Tu es un expert en veille technologique spécialisé dans l'IA. Tu fournis des informations précises avec sources vérifiées."
                        },
                        {
                            "role": "user",
                            "content": query
                        }
                    ],
                    "temperature": 0.2,
                    "max_tokens": 2000
                },
                timeout=60
            )
            
            response.raise_for_status()
            result = response.json()
            
            news_content = result['choices'][0]['message']['content']
            citations = result.get('citations', [])
            
            print(f"✅ {len(citations)} sources citées")
            
            return news_content
            
        except Exception as e:
            print(f"❌ Erreur Perplexity: {e}")
            return None
    
    def synthesize_with_gpt(self, raw_news: str) -> Dict:
        """Génère une synthèse structurée avec GPT-4"""
        
        print("🤖 Génération de la synthèse avec GPT-4...")
        
        prompt = f"""
Voici les actualités IA collectées aujourd'hui :

{raw_news}

Génère une synthèse professionnelle structurée en JSON avec ce format :

{{
  "date": "{self.today}",
  "summary": "Résumé exécutif en 2-3 phrases des tendances principales",
  "top_news": [
    {{
      "title": "Titre de l'actualité",
      "category": "Modèles|Produits|Recherche|Business|Régulation|Cas d'usage",
      "importance": "high|medium|low",
      "summary": "Résumé en 2-3 phrases",
      "source": "Nom de la source",
      "url": "URL si disponible",
      "key_takeaways": ["Point clé 1", "Point clé 2"],
      "impact": "Impact potentiel pour les entreprises"
    }}
  ],
  "trends": [
    "Tendance 1 observée",
    "Tendance 2 observée"
  ],
  "recommendations": [
    "Recommandation 1 pour IMOTION",
    "Recommandation 2 pour IMOTION"
  ]
}}

Sélectionne les 5-7 actualités les plus importantes et pertinentes pour une agence marketing B2B comme IMOTION.
"""
        
        try:
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                max_tokens=4000,
                temperature=0.3,
                messages=[
                    {
                        "role": "system",
                        "content": "Tu es un expert en veille technologique spécialisé dans l'IA. Tu fournis des informations précises et structurées en JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            
            synthesis_text = response.choices[0].message.content
            
            # Extraire le JSON
            import re
            json_match = re.search(r'\{[\s\S]*\}', synthesis_text)
            if json_match:
                synthesis = json.loads(json_match.group())
                print(f"✅ Synthèse générée : {len(synthesis.get('top_news', []))} actualités")
                return synthesis
            else:
                print("⚠️ Format JSON non trouvé, retour du texte brut")
                return {"raw": synthesis_text}
                
        except Exception as e:
            print(f"❌ Erreur GPT-4: {e}")
            return None
    
    def generate_html_report(self, synthesis: Dict) -> str:
        """Génère un rapport HTML professionnel"""
        
        print("📄 Génération du rapport HTML...")
        
        html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veille IA Quotidienne - {synthesis['date']}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        
        body {{
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            color: #1E293B;
            background: #F8FAFC;
            margin: 0;
            padding: 20px;
        }}
        
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        .header h1 {{
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 700;
        }}
        
        .header .date {{
            font-size: 16px;
            opacity: 0.9;
        }}
        
        .content {{
            padding: 40px;
        }}
        
        .summary {{
            background: #EFF6FF;
            border-left: 4px solid #3B82F6;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 8px;
        }}
        
        .summary h2 {{
            margin: 0 0 10px 0;
            color: #1E3A8A;
            font-size: 18px;
        }}
        
        .news-item {{
            border-left: 4px solid #E2E8F0;
            padding: 20px;
            margin-bottom: 20px;
            background: #F8FAFC;
            border-radius: 8px;
            transition: all 0.3s ease;
        }}
        
        .news-item:hover {{
            border-left-color: #3B82F6;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        
        .news-item.high {{
            border-left-color: #EF4444;
            background: #FEF2F2;
        }}
        
        .news-item.medium {{
            border-left-color: #F59E0B;
            background: #FEF3C7;
        }}
        
        .news-title {{
            font-size: 20px;
            font-weight: 600;
            color: #1E3A8A;
            margin: 0 0 10px 0;
        }}
        
        .news-meta {{
            display: flex;
            gap: 15px;
            margin-bottom: 10px;
            font-size: 14px;
            color: #64748B;
        }}
        
        .badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }}
        
        .badge.high {{
            background: #FEE2E2;
            color: #DC2626;
        }}
        
        .badge.medium {{
            background: #FEF3C7;
            color: #D97706;
        }}
        
        .badge.low {{
            background: #DBEAFE;
            color: #2563EB;
        }}
        
        .key-takeaways {{
            background: white;
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
        }}
        
        .key-takeaways h4 {{
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #1E3A8A;
        }}
        
        .key-takeaways ul {{
            margin: 0;
            padding-left: 20px;
        }}
        
        .trends, .recommendations {{
            background: #F0FDF4;
            border-left: 4px solid #10B981;
            padding: 20px;
            margin: 30px 0;
            border-radius: 8px;
        }}
        
        .recommendations {{
            background: #FEF3C7;
            border-left-color: #F59E0B;
        }}
        
        .footer {{
            background: #F8FAFC;
            padding: 20px;
            text-align: center;
            color: #64748B;
            font-size: 14px;
        }}
        
        a {{
            color: #3B82F6;
            text-decoration: none;
        }}
        
        a:hover {{
            text-decoration: underline;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Veille IA Quotidienne</h1>
            <p class="date">{synthesis['date']}</p>
        </div>
        
        <div class="content">
            <div class="summary">
                <h2>📊 Résumé Exécutif</h2>
                <p>{synthesis.get('summary', 'Aucun résumé disponible')}</p>
            </div>
            
            <h2>🔥 Actualités Principales</h2>
"""
        
        # Ajouter les actualités
        for news in synthesis.get('top_news', []):
            importance = news.get('importance', 'medium')
            html += f"""
            <div class="news-item {importance}">
                <h3 class="news-title">{news['title']}</h3>
                <div class="news-meta">
                    <span class="badge {importance}">{importance.upper()}</span>
                    <span>📁 {news.get('category', 'N/A')}</span>
                    <span>📰 {news.get('source', 'N/A')}</span>
                </div>
                <p>{news['summary']}</p>
"""
            
            if news.get('key_takeaways'):
                html += """
                <div class="key-takeaways">
                    <h4>💡 Points Clés</h4>
                    <ul>
"""
                for takeaway in news['key_takeaways']:
                    html += f"                        <li>{takeaway}</li>\n"
                html += """
                    </ul>
                </div>
"""
            
            if news.get('impact'):
                html += f"                <p><strong>Impact :</strong> {news['impact']}</p>\n"
            
            if news.get('url'):
                html += f'                <p><a href="{news["url"]}" target="_blank">Lire l\'article →</a></p>\n'
            
            html += "            </div>\n"
        
        # Ajouter les tendances
        if synthesis.get('trends'):
            html += """
            <div class="trends">
                <h3>📈 Tendances Observées</h3>
                <ul>
"""
            for trend in synthesis['trends']:
                html += f"                    <li>{trend}</li>\n"
            html += """
                </ul>
            </div>
"""
        
        # Ajouter les recommandations
        if synthesis.get('recommendations'):
            html += """
            <div class="recommendations">
                <h3>💡 Recommandations pour IMOTION</h3>
                <ul>
"""
            for rec in synthesis['recommendations']:
                html += f"                    <li>{rec}</li>\n"
            html += """
                </ul>
            </div>
"""
        
        html += """
        </div>
        
        <div class="footer">
            <p>Généré automatiquement par le système de veille IA IMOTION</p>
            <p>© 2025 IMOTION - Tous droits réservés</p>
        </div>
    </div>
</body>
</html>
"""
        
        return html
    
    def save_reports(self, synthesis: Dict, html: str):
        """Sauvegarde les rapports JSON et HTML"""
        
        print("💾 Sauvegarde des rapports...")
        
        # Créer le répertoire de sortie si nécessaire
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        # Sauvegarder le JSON
        json_path = f"{OUTPUT_DIR}/ai_news_{self.today}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(synthesis, f, ensure_ascii=False, indent=2)
        print(f"✅ JSON sauvegardé : {json_path}")
        
        # Sauvegarder le HTML
        html_path = f"{OUTPUT_DIR}/ai_news_{self.today}.html"
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"✅ HTML sauvegardé : {html_path}")
        
        return json_path, html_path
    
    def send_email_notification(self, html_path: str, synthesis: Dict):
        """Envoie le rapport par email (placeholder)"""
        
        print(f"📧 Envoi du rapport à {EMAIL_RECIPIENT}...")
        
        # TODO: Implémenter l'envoi d'email avec Resend ou SendGrid
        # Pour l'instant, juste afficher le chemin
        print(f"✅ Rapport disponible : {html_path}")
        print(f"   {len(synthesis.get('top_news', []))} actualités collectées")
    
    def run(self):
        """Exécute le processus complet de collecte"""
        
        print("=" * 60)
        print(f"🚀 Démarrage de la collecte d'actualités IA - {self.today}")
        print("=" * 60)
        
        # 1. Collecter les actualités
        raw_news = self.collect_news_perplexity()
        if not raw_news:
            print("❌ Échec de la collecte")
            return False
        
        # 2. Générer la synthèse
        synthesis = self.synthesize_with_gpt(raw_news)
        if not synthesis:
            print("❌ Échec de la synthèse")
            return False
        
        # 3. Générer le rapport HTML
        html = self.generate_html_report(synthesis)
        
        # 4. Sauvegarder les rapports
        json_path, html_path = self.save_reports(synthesis, html)
        
        # 5. Envoyer la notification
        self.send_email_notification(html_path, synthesis)
        
        print("=" * 60)
        print("✅ Collecte terminée avec succès !")
        print("=" * 60)
        
        return True

def main():
    """Point d'entrée principal"""
    
    # Vérifier les clés API
    if not PERPLEXITY_API_KEY:
        print("❌ SONAR_API_KEY non définie")
        return 1
    
    if not OPENAI_API_KEY:
        print("❌ OPENAI_API_KEY non définie")
        return 1
    
    # Exécuter la collecte
    collector = AINewsCollector()
    success = collector.run()
    
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())
