#!/bin/bash
#
# Script de Configuration du CRON Job
# Exécute la collecte d'actualités IA tous les jours à 9h00
#

echo "🔧 Configuration du CRON job pour la veille IA..."

# Chemin du script
SCRIPT_PATH="/home/ubuntu/ai-news-collector/scripts/collect_ai_news.py"
LOG_PATH="/home/ubuntu/ai-news-collector/data/cron.log"

# Vérifier que le script existe
if [ ! -f "$SCRIPT_PATH" ]; then
    echo "❌ Script non trouvé : $SCRIPT_PATH"
    exit 1
fi

# Créer le répertoire de logs
mkdir -p "$(dirname "$LOG_PATH")"

# Ajouter la tâche CRON (tous les jours à 9h00)
CRON_JOB="0 9 * * * cd /home/ubuntu/ai-news-collector && /usr/bin/python3 $SCRIPT_PATH >> $LOG_PATH 2>&1"

# Vérifier si la tâche existe déjà
if crontab -l 2>/dev/null | grep -q "$SCRIPT_PATH"; then
    echo "⚠️  Tâche CRON déjà configurée"
    echo "   Pour la supprimer : crontab -e"
else
    # Ajouter la tâche
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
    echo "✅ Tâche CRON ajoutée avec succès"
    echo "   Exécution : Tous les jours à 9h00"
    echo "   Logs : $LOG_PATH"
fi

# Afficher les tâches CRON actuelles
echo ""
echo "📋 Tâches CRON actuelles :"
crontab -l

echo ""
echo "✅ Configuration terminée !"
echo ""
echo "Pour tester immédiatement :"
echo "  python3 $SCRIPT_PATH"
