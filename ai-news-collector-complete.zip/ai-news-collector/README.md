# 🤖 Système de Veille IA Automatique

Collecte et synthèse quotidienne des actualités de l'industrie de l'IA avec notification par email.

---

## 🎯 Fonctionnalités

✅ **Collecte automatique** : Perplexity API (sources vérifiées)  
✅ **Synthèse intelligente** : Claude 3.5 Sonnet (structuration)  
✅ **Rapport HTML professionnel** : Design IMOTION premium  
✅ **Exécution quotidienne** : CRON job à 9h00  
✅ **Notification email** : Envoi automatique à patrice.simion@gmail.com  
✅ **Historique** : Sauvegarde JSON + HTML

---

## 📦 Structure

```
ai-news-collector/
├── scripts/
│   └── collect_ai_news.py       # Script principal
├── templates/
│   └── (futurs templates email)
├── data/
│   ├── ai_news_YYYY-MM-DD.json  # Données brutes
│   ├── ai_news_YYYY-MM-DD.html  # Rapport HTML
│   └── cron.log                 # Logs d'exécution
├── setup_cron.sh                # Configuration CRON
└── README.md                    # Ce fichier
```

---

## 🚀 Installation

### 1. Vérifier les Clés API

Les variables d'environnement suivantes doivent être définies :

```bash
export SONAR_API_KEY="votre_clé_perplexity"
export ANTHROPIC_API_KEY="votre_clé_anthropic"
```

✅ **Déjà configuré** dans votre environnement sandbox

### 2. Installer les Dépendances Python

```bash
pip3 install anthropic requests
```

### 3. Configurer le CRON Job

```bash
cd /home/ubuntu/ai-news-collector
./setup_cron.sh
```

Cela configurera l'exécution automatique tous les jours à **9h00**.

---

## 🧪 Test Manuel

Pour tester immédiatement sans attendre le CRON :

```bash
cd /home/ubuntu/ai-news-collector
python3 scripts/collect_ai_news.py
```

**Résultat attendu** :
- ✅ Collecte des actualités via Perplexity
- ✅ Synthèse générée par Claude
- ✅ Rapport HTML créé dans `data/`
- ✅ Notification (placeholder pour l'instant)

---

## 📊 Exemple de Sortie

### Rapport JSON (`ai_news_2025-11-13.json`)

```json
{
  "date": "2025-11-13",
  "summary": "Aujourd'hui, OpenAI a annoncé GPT-5, Google a lancé Gemini 2.0, et une nouvelle régulation IA a été votée en Europe...",
  "top_news": [
    {
      "title": "OpenAI annonce GPT-5 avec des capacités multimodales avancées",
      "category": "Modèles",
      "importance": "high",
      "summary": "OpenAI dévoile GPT-5, capable de traiter simultanément texte, image, audio et vidéo...",
      "source": "TechCrunch",
      "url": "https://...",
      "key_takeaways": [
        "Multimodalité native",
        "Réduction de 50% des hallucinations"
      ],
      "impact": "Opportunité pour améliorer les audits IA d'IMOTION"
    }
  ],
  "trends": [
    "Accélération de la multimodalité",
    "Focus sur la réduction des hallucinations"
  ],
  "recommendations": [
    "Explorer l'intégration de GPT-5 dans MANUS IA 2.0",
    "Créer un article de blog sur les implications pour le B2B"
  ]
}
```

### Rapport HTML

Un rapport HTML professionnel avec :
- 🎨 Design IMOTION (gradients bleu, typographie Inter)
- 📊 Résumé exécutif
- 🔥 5-7 actualités principales (classées par importance)
- 📈 Tendances observées
- 💡 Recommandations pour IMOTION

---

## ⏰ Configuration CRON

### Horaire par Défaut

- **Fréquence** : Tous les jours
- **Heure** : 9h00 (heure du serveur)
- **Logs** : `/home/ubuntu/ai-news-collector/data/cron.log`

### Modifier l'Horaire

```bash
crontab -e
```

Exemples :
- `0 9 * * *` → Tous les jours à 9h00
- `0 9,18 * * *` → Tous les jours à 9h00 et 18h00
- `0 9 * * 1-5` → Du lundi au vendredi à 9h00

### Vérifier les Logs

```bash
tail -f /home/ubuntu/ai-news-collector/data/cron.log
```

---

## 📧 Configuration Email (À Faire)

### Option 1 : Resend (Recommandé)

```python
import resend

resend.api_key = os.getenv("RESEND_API_KEY")

resend.Emails.send({
    "from": "veille@imotion.fr",
    "to": "patrice.simion@gmail.com",
    "subject": f"Veille IA Quotidienne - {date}",
    "html": html_content
})
```

### Option 2 : SendGrid

```python
import sendgrid
from sendgrid.helpers.mail import Mail

sg = sendgrid.SendGridAPIClient(api_key=os.getenv("SENDGRID_API_KEY"))

message = Mail(
    from_email="veille@imotion.fr",
    to_emails="patrice.simion@gmail.com",
    subject=f"Veille IA Quotidienne - {date}",
    html_content=html_content
)

sg.send(message)
```

---

## 🎯 Cas d'Usage

### 1. Veille Quotidienne

- Recevoir chaque matin un résumé des actualités IA
- Identifier les tendances émergentes
- Repérer les opportunités business

### 2. Génération de Contenu

- Utiliser les actualités pour créer des articles de blog
- Alimenter les réseaux sociaux (LinkedIn, Twitter)
- Créer des newsletters clients

### 3. Stratégie Produit

- Identifier les nouvelles technologies à intégrer
- Anticiper les évolutions du marché
- Ajuster la roadmap MANUS IA 2.0

---

## 📈 Évolutions Futures

### Phase 2 (Semaine prochaine)

- [ ] Intégration Resend pour l'envoi d'emails
- [ ] Template email responsive
- [ ] Pièce jointe PDF du rapport

### Phase 3 (Mois prochain)

- [ ] Intégration avec Supabase (stockage BDD)
- [ ] Dashboard web pour consulter l'historique
- [ ] Filtres par catégorie (Modèles, Produits, Recherche, etc.)
- [ ] Recherche full-text dans l'historique

### Phase 4 (Trimestre)

- [ ] Génération automatique d'articles de blog
- [ ] Publication automatique sur le site IMOTION
- [ ] Partage automatique sur LinkedIn
- [ ] Alertes personnalisées par mot-clé

---

## 🔧 Dépannage

### Problème : Pas d'actualités collectées

**Cause** : Clé API Perplexity invalide ou expirée

**Solution** :
```bash
echo $SONAR_API_KEY  # Vérifier la clé
```

### Problème : Synthèse non générée

**Cause** : Clé API Anthropic invalide ou quota dépassé

**Solution** :
```bash
echo $ANTHROPIC_API_KEY  # Vérifier la clé
# Vérifier le quota sur console.anthropic.com
```

### Problème : CRON ne s'exécute pas

**Cause** : Service cron non démarré

**Solution** :
```bash
sudo service cron status
sudo service cron start
```

### Problème : Erreur d'import Python

**Cause** : Dépendances manquantes

**Solution** :
```bash
pip3 install anthropic requests
```

---

## 📞 Support

Pour toute question ou problème :
- 📧 Email : patrice.simion@gmail.com
- 🐛 Issues : Créer un ticket dans le projet

---

## 📄 Licence

© 2025 IMOTION - Usage interne uniquement

---

## 🎉 Prochaines Étapes

1. ✅ **Tester** : Exécuter manuellement le script
2. ✅ **Configurer** : Installer le CRON job
3. ✅ **Vérifier** : Consulter le premier rapport demain matin
4. 🔜 **Intégrer** : Ajouter l'envoi d'emails
5. 🔜 **Automatiser** : Générer des articles de blog

Bon monitoring ! 🚀
